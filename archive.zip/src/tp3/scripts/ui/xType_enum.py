import enum

class xAxisTypes(enum.Enum):
    NotSelected = 0
    Time = 1
    ObjID = 2